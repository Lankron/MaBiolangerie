<?php

/*
 * Database configuration settings used by PDO.
 */

$config['dsn']      = 'mysql:host=localhost;dbname=id8522287_baguette';
$config['password'] = 'horriblesite';
$config['user']     = 'id8522287_cetruc';
