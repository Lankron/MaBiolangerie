<?php

class RecappanierController
{
    public function httpGetMethod(Http $http, array $queryFields)
    {
        session_start();

        $id_user = $_SESSION["id_client"];

        $InfoClient = new LoginModel();
        $InfoUser = $InfoClient->InfoUser($id_user);


        $id = $queryFields["id"];
        $OrderModel = new OrdersModel();

        $RecapPanier = $OrderModel->RecapOrder($id);
        $RecapSumPanier = $OrderModel->RecapSumOrder($id);


        return ["RecapPanier" => $RecapPanier,
                "RecapSumPanier" => $RecapSumPanier,
                "InfoUser" => $InfoUser];
        // RECUPERE L ID DEPUIS BreadView dans la table categorybread


        /*
         * Méthode appelée en cas de requête HTTP GET
         *
         * L'argument $http est un objet permettant de faire des redirections etc.
         * L'argument $queryFields contient l'équivalent de $_GET en PHP natif.
         */
    }

    public function httpPostMethod(Http $http, array $formFields)
    {



        /*
         * Méthode appelée en cas de requête HTTP POST
         *
         * L'argument $http est un objet permettant de faire des redirections etc.
         * L'argument $formFields contient l'équivalent de $_POST en PHP natif.
         */
    }
}