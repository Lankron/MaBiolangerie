<?php

class AddcategorypastryController
{
    public function httpGetMethod(Http $http, array $queryFields)
    {



        // RECUPERE L ID DEPUIS SodaView dans la table categorysoda

        /*
         * Méthode appelée en cas de requête HTTP GET
         *
         * L'argument $http est un objet permettant de faire des redirections etc.
         * L'argument $queryFields contient l'équivalent de $_GET en PHP natif.
         */
    }

    public function httpPostMethod(Http $http, array $formFields)
    {


        $folderName = "image_category/";
        $dossier = WWW_PATH ."/".'images/'.$folderName;

        $taille_maxi = 100000;

        $taille = filesize($_FILES['fichier']['tmp_name']);

        $extensions = array('.png', '.gif', '.jpg', '.jpeg');
        $Category = new CategoryproductModel();
        if($_FILES["fichier"]["tmp_name"] != "") {
            $fileName = explode(".", $_FILES["fichier"]["name"])[0];
            $extension = explode(".", $_FILES["fichier"]["name"])[1];


            //var_dump($_FILES['fichier']['tmp_name']);

            if (!file_exists($dossier))
                mkdir($dossier, 0777, true);


            if (move_uploaded_file($_FILES['fichier']['tmp_name'], $dossier . "/" . $fileName . "." . $extension)) //Si la fonction renvoie TRUE,             c'est que ça a fonctionné...
            {
                echo 'Upload effectué avec succès !';
            }


            $Category->AddCategoryPastry($fileName . "." . $extension, $formFields["name"]);
        }
        else{
            $Category->AddCategoryPastry("none.png", $formFields["name"]);
        }

        $http->redirectTo("/pastry");



        /*
         * Méthode appelée en cas de requête HTTP POST
         *
         * L'argument $http est un objet permettant de faire des redirections etc.
         * L'argument $formFields contient l'équivalent de $_POST en PHP natif.
         */
    }
}