<?php

class DeletecategorysodaController
{
    public function httpGetMethod(Http $http, array $queryFields)
    {
        $idCategory = $queryFields["id"];
        $Namecategory = $queryFields["category"];

        $Category = new CategoryproductModel();
        $ids = $Category->getCategoryProductSoda($Namecategory);

        foreach($ids as $id){
            $Category->deleteProduct($id["id_product"]);
        }

        $Category->DeleteCategorySoda($idCategory);
        $http->redirectTo("/soda");
        // RECUPERE L ID DEPUIS SodaView dans la table categorysoda

        /*
         * Méthode appelée en cas de requête HTTP GET
         *
         * L'argument $http est un objet permettant de faire des redirections etc.
         * L'argument $queryFields contient l'équivalent de $_GET en PHP natif.
         */
    }

    public function httpPostMethod(Http $http, array $formFields)
    {





        /*
         * Méthode appelée en cas de requête HTTP POST
         *
         * L'argument $http est un objet permettant de faire des redirections etc.
         * L'argument $formFields contient l'équivalent de $_POST en PHP natif.
         */
    }
}