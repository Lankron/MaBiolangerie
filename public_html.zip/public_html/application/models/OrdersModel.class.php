<?php


class OrdersModel
{

    function AddOrderNumberOnDatabase($id_client){

        $database = new Database();

        return $database->executeSql("INSERT INTO `orders`(`orderdate`, `id_client`) VALUES (NOW(),?)",[$id_client]);

    }

    function AddOrderDetailsOnDatabase($id_products,$quantityordered,$priceHT,$priceTVA,$priceTTC,$ordernumber){

        $database = new Database();

      $sql =  "INSERT INTO `orderdetails`( `id_products`, `quantityordered`, `priceHT`, `priceTVA`, `priceTTC`, `ordernumber`) VALUES (?,?,?,?,?,?)";

        $database->executeSql($sql,[$id_products,$quantityordered,$priceHT,$priceTVA,$priceTTC,$ordernumber]);

    }

    function RecapOrder($id){

        $database = new Database();

        $sql =  "SELECT orders.id_orders, `orderdate`,orders.id_client,`quantityordered`,(priceHT*quantityordered) as prixHT, `photo`,`name` FROM `orders` INNER JOIN orderdetails ON orders.id_orders=orderdetails.ordernumber INNER JOIN login ON orders.id_client=login.id INNER JOIN allproducts ON allproducts.id_product=orderdetails.id_products WHERE orders.id_orders = ?";

       return $database->query($sql,[$id]);

    }

    function RecapSumOrder($id){

        $database = new Database();

        $sql =  "SELECT orders.id_orders, orders.id_client,SUM(priceHT*quantityordered) as prixHT,SUM(priceTVA) as prixTVA ,SUM(priceTTC) as prixTTC FROM `orders` INNER JOIN orderdetails ON orders.id_orders=orderdetails.ordernumber WHERE orders.id_orders = ?";

        return $database->queryOne($sql,[$id]);

    }

    function PaiementSuccess($statut,$id_orders){

        $database = new Database();

        $sql = "UPDATE `orders` SET `Statut`= ? WHERE `id_orders` = ?";

        $database->executeSql($sql,[$statut,$id_orders]);

    }



}