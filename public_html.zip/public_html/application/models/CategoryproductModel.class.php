<?php


class CategoryproductModel
{

    // affiche tout les différents type de pains
    function AffichageCategoryBread(){

        $database = new Database();

       return $database->query("SELECT * FROM categorybread");
    }
    // affiche tout les différents type de pâtisseries
    function AffichageCategoryPastry(){

        $database = new Database();

        return $database->query("SELECT * FROM categorypastry");
    }
    // affiche tout les différents type de sandwich
    function AffichageCategorySandwich(){

        $database = new Database();

        return $database->query("SELECT * FROM categorysandwich");
    }
    // affiche tout les différents type de boissons
    function AffichageCategorySoda(){

        $database = new Database();

        return $database->query("SELECT * FROM categorysoda");
    }

    function getCategoryProductBread($categoryName){
        $database = new Database();
        return $database->query("SELECT id_product FROM allproducts WHERE categoryproduct = ?", [$categoryName]);
    }

    function getCategoryProductPastry($categoryName){
        $database = new Database();
        return $database->query("SELECT id_product FROM allproducts WHERE categoryproduct = ?", [$categoryName]);
    }
    function getCategoryProductSandwich($categoryName){
        $database = new Database();
        return $database->query("SELECT id_product FROM allproducts WHERE categoryproduct = ?", [$categoryName]);
    }
    function getCategoryProductSoda($categoryName){
        $database = new Database();
        return $database->query("SELECT id_product FROM allproducts WHERE categoryproduct = ?", [$categoryName]);
    }

    // affiche LA CATEGORIE de pain choisi grace a l'id
    function AfficheCategoryProductBread($id){
        $database = new Database();

        return $database->query("SELECT `id_product`, id, `name`, allproducts.photo, `description`, `categoryproduct`, `quantityinstock`, `buyprice`, `saleprice` FROM `allproducts` INNER JOIN categorybread ON categorybread.CategoryBread=allproducts.categoryproduct WHERE id = ?", [$id]); // l'id vient de l'url, qui lui vient de breadview, dans la table categorybread dans sql.
    }
    // affiche le titre de la catégory de produit de pain

    function AfficheTitleBreadCategoryProduct($id){
        $database = new Database();

        return $database->queryOne("SELECT CategoryBread FROM categorybread WHERE id = ?", [$id]); // l'id vient de l'url, qui lui vient de breadview, dans la table categorybread dans sql.
    }





    // affiche LA CATEGORIE de patisseries choisi grace a l'id
    function AfficheCategoryProductPastry($id){
        $database = new Database();

        return $database->query("SELECT `id_product`, id, `name`, allproducts.photo, `description`, `categoryproduct`, `quantityinstock`, `buyprice`, `saleprice` FROM `allproducts` INNER JOIN categorypastry ON categorypastry.categorypastry=allproducts.categoryproduct WHERE id = ?", [$id]); // l'id vient de l'url, qui lui vient de breadview, dans la table categorybread dans sql.
    }
    // affiche le titre de la catégory de produit de patisseries
    function AfficheTitlePastryCategoryProduct($id){
        $database = new Database();

        return $database->queryOne("SELECT categorypastry FROM categorypastry WHERE id = ?", [$id]); // l'id vient de l'url, qui lui vient de breadview, dans la table categorybread dans sql.
    }




    function AfficheCategoryProductSandwich($id){
        $database = new Database();

        return $database->query("SELECT `id_product`, id, `name`, allproducts.photo, `description`, `categoryproduct`, `quantityinstock`, `buyprice`, `saleprice` FROM `allproducts` INNER JOIN categorysandwich ON categorysandwich.categorysandwich=allproducts.categoryproduct WHERE id = ?", [$id]); // l'id vient de l'url, qui lui vient de breadview, dans la table categorybread dans sql.
    }
    // affiche le titre de la catégory de produit de pain
    function AfficheTitleSandwichCategoryProduct($id){
        $database = new Database();

        return $database->queryOne("SELECT categorysandwich FROM categorysandwich WHERE id = ?", [$id]); // l'id vient de l'url, qui lui vient de breadview, dans la table categorybread dans sql.
    }




    function AfficheCategoryProductSoda($id){
        $database = new Database();

        return $database->query("SELECT `id_product`, id, `name`, allproducts.photo, `description`, `categoryproduct`, `quantityinstock`, `buyprice`, `saleprice` FROM `allproducts` INNER JOIN categorysoda ON categorysoda.categorysoda=allproducts.categoryproduct WHERE id = ?", [$id]); // l'id vient de l'url, qui lui vient de breadview, dans la table categorybread dans sql.
    }
    // affiche le titre de la catégory de produit de pain
    function AfficheTitleSodaCategoryProduct($id){
        $database = new Database();

        return $database->queryOne("SELECT categorysoda FROM categorysoda WHERE id = ?",[$id]); // l'id vient de l'url, qui lui vient de breadview, dans la table categorybread dans sql.
    }

    function deleteProduct($id){
        $database = new Database();
        $database->executeSql("DELETE FROM allproducts WHERE id_product = ?", [$id]);
    }

    // on récupère qu'un seul produit pour le mettre dans le panier
    function OneProductRecuperedById($id){
        $database = new Database();

        return $database->queryOne("SELECT * FROM allproducts WHERE id_product = ?", [$id]);
    }

    // supprimer la categorie

    function DeleteCategoryBread($id){


        $database = new Database();

        return $database->executeSql("DELETE FROM `categorybread` WHERE id = ?", [$id]);


    }
    function DeleteCategoryPastry($id){


        $database = new Database();

        return $database->executeSql("DELETE FROM `categorypastry` WHERE id = ?", [$id]);


    }

    function DeleteCategorySandwich($id){


        $database = new Database();

        return $database->executeSql("DELETE FROM `categorysandwich` WHERE id = ?", [$id]);


    }

    function DeleteCategorySoda($id){


        $database = new Database();

        return $database->executeSql("DELETE FROM `categorysoda` WHERE id = ?", [$id]);


    }

    function DeleteCategoryProductBread($id){

        $database = new Database();

        return $database->executeSql("DELETE FROM `allproducts` WHERE id_product = ?", [$id]);
    }

    function DeleteCategoryProductPastry($id){

        $database = new Database();

        return $database->executeSql("DELETE FROM `allproducts` WHERE id_product = ?", [$id]);
    }

    function DeleteCategoryProductSandwich($id){

        $database = new Database();

        return $database->executeSql("DELETE FROM `allproducts` WHERE id_product = ?", [$id]);
    }

    function DeleteCategoryProductSoda($id){

        $database = new Database();

        return $database->executeSql("DELETE FROM `allproducts` WHERE id_product = ?", [$id]);
    }

    function AddCategoryBread($photo,$category){


        $database = new Database();

        return $database->executeSql("INSERT INTO `categorybread`(`photo`, `CategoryBread`) VALUES (?,?)", [$photo,$category]);


    }
    function AddCategoryPastry($photo,$category){


        $database = new Database();

        return $database->executeSql("INSERT INTO `categorypastry`(`photo`, `categorypastry`) VALUES (?,?)", [$photo,$category]);


    }

    function AddCategorySandwich($photo,$category){


        $database = new Database();

        return $database->executeSql("INSERT INTO `categorysandwich`(`photo`, `categorysandwich`) VALUES (?,?)", [$photo,$category]);


    }

    function AddCategorySoda($photo,$category){


        $database = new Database();

        return $database->executeSql("INSERT INTO `categorysoda`(`photo`, `categorysoda`) VALUES (?,?)", [$photo,$category]);


    }

    function AddCategoryProductBread($name, $photo, $description, $categoryProduct, $quantity, $buyPrice, $salePrice){


        $database = new Database();

        return $database->executeSql("INSERT INTO `allproducts`(`name`, `photo`, `description`, `categoryproduct`, `quantityinstock`, `buyprice`, `saleprice`) VALUES (?,?,?,?,?,?,?)", [$name, $photo, $description, $categoryProduct, $quantity, $buyPrice, $salePrice]);


    }

    function AddCategoryProductPastry($name, $photo, $description, $categoryProduct, $quantity, $buyPrice, $salePrice){


        $database = new Database();

        return $database->executeSql("INSERT INTO `allproducts`(`name`, `photo`, `description`, `categoryproduct`, `quantityinstock`, `buyprice`, `saleprice`) VALUES (?,?,?,?,?,?,?)", [$name, $photo, $description, $categoryProduct, $quantity, $buyPrice, $salePrice]);


    }

    function AddCategoryProductSandwich($name, $photo, $description, $categoryProduct, $quantity, $buyPrice, $salePrice){


        $database = new Database();

        return $database->executeSql("INSERT INTO `allproducts`(`name`, `photo`, `description`, `categoryproduct`, `quantityinstock`, `buyprice`, `saleprice`) VALUES (?,?,?,?,?,?,?)", [$name, $photo, $description, $categoryProduct, $quantity, $buyPrice, $salePrice]);


    }

    function AddCategoryProductSoda($name, $photo, $description, $categoryProduct, $quantity, $buyPrice, $salePrice){


        $database = new Database();

        return $database->executeSql("INSERT INTO `allproducts`(`name`, `photo`, `description`, `categoryproduct`, `quantityinstock`, `buyprice`, `saleprice`) VALUES (?,?,?,?,?,?,?)", [$name, $photo, $description, $categoryProduct, $quantity, $buyPrice, $salePrice]);


    }

    function EditCategoryBread($id,$image,$NameCategorie){

        $database = new Database();

        return $database->executeSql("UPDATE `categorybread` SET`photo`= ?,`CategoryBread`= ? WHERE id = ?",[$image,$NameCategorie,$id]);

    }
    function EditCategoryBreadForProduct($EditCategorie,$NameCategorie){

        $database = new Database();

        return $database->executeSql("UPDATE `allproducts` SET `categoryproduct`= ? WHERE categoryproduct = ?",[$EditCategorie,$NameCategorie]);

    }

    function EditCategoryroductBread($name,$photo,$description,$quantity,$prix,$id){

        $database = new Database();

        return $database->executeSql("UPDATE `allproducts` SET `name`= ?,`photo`= ?,`description`= ?,`quantityinstock`= ? ,`saleprice`= ? WHERE id_product = ?",[$name,$photo,$description,$quantity,$prix,$id]);

    }

    function EditCategoryPastry($id,$image,$NameCategorie){

        $database = new Database();

        return $database->executeSql("UPDATE `categorypastry` SET`photo`= ?,`categorypastry`= ? WHERE id = ?",[$image,$NameCategorie,$id]);

    }
    function EditCategoryPastryForProduct($EditCategorie,$NameCategorie){

        $database = new Database();

        return $database->executeSql("UPDATE `allproducts` SET `categoryproduct`= ? WHERE categoryproduct = ?",[$EditCategorie,$NameCategorie]);

    }

    function EditCategoryroductPastry($name,$photo,$description,$quantity,$prix,$id){

        $database = new Database();

        return $database->executeSql("UPDATE `allproducts` SET `name`= ?,`photo`= ?,`description`= ?,`quantityinstock`= ? ,`saleprice`= ? WHERE id_product = ?",[$name,$photo,$description,$quantity,$prix,$id]);

    }

    function EditCategorySandwich($id,$image,$NameCategorie){

        $database = new Database();

        return $database->executeSql("UPDATE `categorysandwich` SET`photo`= ?,`categorysandwich`= ? WHERE id = ?",[$image,$NameCategorie,$id]);

    }
    function EditCategorySandwichForProduct($EditCategorie,$NameCategorie){

        $database = new Database();

        return $database->executeSql("UPDATE `allproducts` SET `categoryproduct`= ? WHERE categoryproduct = ?",[$EditCategorie,$NameCategorie]);

    }

    function EditCategoryroductSandwich($name,$photo,$description,$quantity,$prix,$id){

        $database = new Database();

        return $database->executeSql("UPDATE `allproducts` SET `name`= ?,`photo`= ?,`description`= ?,`quantityinstock`= ? ,`saleprice`= ? WHERE id_product = ?",[$name,$photo,$description,$quantity,$prix,$id]);

    }

    function EditCategorySoda($id,$image,$NameCategorie){

        $database = new Database();

        return $database->executeSql("UPDATE `categorysoda` SET`photo`= ?,`categorysoda`= ? WHERE id = ?",[$image,$NameCategorie,$id]);

    }
    function EditCategorySodaForProduct($EditCategorie,$NameCategorie){

        $database = new Database();

        return $database->executeSql("UPDATE `allproducts` SET `categoryproduct`= ? WHERE categoryproduct = ?",[$EditCategorie,$NameCategorie]);

    }

    function EditCategoryroductSoda($name,$photo,$description,$quantity,$prix,$id){

        $database = new Database();

        return $database->executeSql("UPDATE `allproducts` SET `name`= ?,`photo`= ?,`description`= ?,`quantityinstock`= ? ,`saleprice`= ? WHERE id_product = ?",[$name,$photo,$description,$quantity,$prix,$id]);

    }







}