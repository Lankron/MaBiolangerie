-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le : ven. 12 fév. 2021 à 19:26
-- Version du serveur :  10.3.16-MariaDB
-- Version de PHP : 7.3.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `id8522287_baguette`
--

-- --------------------------------------------------------

--
-- Structure de la table `allproducts`
--

CREATE TABLE `allproducts` (
  `id_product` int(5) NOT NULL,
  `name` varchar(50) NOT NULL,
  `photo` varchar(200) DEFAULT 'rien.jpg',
  `description` text CHARACTER SET utf8 NOT NULL,
  `categoryproduct` varchar(50) NOT NULL,
  `quantityinstock` int(11) NOT NULL,
  `buyprice` double NOT NULL,
  `saleprice` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `allproducts`
--

INSERT INTO `allproducts` (`id_product`, `name`, `photo`, `description`, `categoryproduct`, `quantityinstock`, `buyprice`, `saleprice`) VALUES
(33, 'crudités olives', 'none.png', '', 'végétariens', 15, 1, 5),
(34, 'Tarte aux framboises', 'none.png', 'Tarte à la crème patissière décorée avec des framboises', 'tartes', 20, 2, 1),
(35, 'Badoit', 'none.png', 'saveur citron', 'gazeuses', 25, 2, 1),
(36, 'Café court', 'none.png', '100% Arabica', 'Boissons chaudes', 30, 1, 3),
(37, 'Thé', 'none.png', 'Vert à la menthe', 'Boissons chaudes', 28, 2, 4),
(38, 'sprite', 'none.png', 'light', 'gazeuses', 18, 1, 2),
(40, 'pain aux céréales', 'none.png', '7 céréales', 'céréales', 18, 1, 2);

-- --------------------------------------------------------

--
-- Structure de la table `astuceday`
--

CREATE TABLE `astuceday` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `photo` varchar(250) NOT NULL,
  `corp` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `astuceday`
--

INSERT INTO `astuceday` (`id`, `title`, `photo`, `corp`) VALUES
(1, 'zaeazeazeaz', 'azeaezaze', 'zeaezezaaez');

-- --------------------------------------------------------

--
-- Structure de la table `categorybread`
--

CREATE TABLE `categorybread` (
  `id` int(5) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `CategoryBread` varchar(30) CHARACTER SET utf8 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `categorybread`
--

INSERT INTO `categorybread` (`id`, `photo`, `CategoryBread`) VALUES
(56, 'none.png', 'céréales'),
(58, 'none.png', 'retert');

-- --------------------------------------------------------

--
-- Structure de la table `categorypastry`
--

CREATE TABLE `categorypastry` (
  `id` int(5) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `categorypastry` varchar(30) CHARACTER SET utf8 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `categorypastry`
--

INSERT INTO `categorypastry` (`id`, `photo`, `categorypastry`) VALUES
(11, 'none.png', 'tartes');

-- --------------------------------------------------------

--
-- Structure de la table `categorysandwich`
--

CREATE TABLE `categorysandwich` (
  `id` int(5) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `categorysandwich` varchar(30) CHARACTER SET utf8 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `categorysandwich`
--

INSERT INTO `categorysandwich` (`id`, `photo`, `categorysandwich`) VALUES
(5, 'none.png', 'végétariens');

-- --------------------------------------------------------

--
-- Structure de la table `categorysoda`
--

CREATE TABLE `categorysoda` (
  `id` int(5) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `categorysoda` varchar(30) CHARACTER SET utf8 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `categorysoda`
--

INSERT INTO `categorysoda` (`id`, `photo`, `categorysoda`) VALUES
(3, 'none.png', 'gazeuses'),
(5, 'none.png', 'Boissons chaudes');

-- --------------------------------------------------------

--
-- Structure de la table `login`
--

CREATE TABLE `login` (
  `id` int(5) NOT NULL,
  `user` varchar(16) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(150) NOT NULL,
  `lastname` varchar(100) CHARACTER SET utf8 NOT NULL,
  `firstname` varchar(100) CHARACTER SET utf8 NOT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `codepostal` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
  `adresse` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `birthdayDAY` int(11) DEFAULT NULL,
  `birthdayMONTH` varchar(30) DEFAULT NULL,
  `birthdayYEAR` int(11) DEFAULT NULL,
  `role` varchar(30) NOT NULL DEFAULT 'membre'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `login`
--

INSERT INTO `login` (`id`, `user`, `password`, `email`, `lastname`, `firstname`, `city`, `codepostal`, `adresse`, `birthdayDAY`, `birthdayMONTH`, `birthdayYEAR`, `role`) VALUES
(11, 'admin', '$2y$10$pLeMELLH.tPRq7SfxLPYe.GB.gP5PRXw.jeEF9fW5LbySIcyEtl/y', 'zak@zak.fr', 'l\'admin', 'zak', 'za', 'za', 'za', 1, 'Janvier', 1950, 'admin'),
(15, 'aa', '$2y$10$czYJIIEPwmZ9LNcJu0PFR.RP77FGV7SeX3vh.rIkPQSknKLAdnn5K', 'aa', 'aa', 'aa', 'zerzer', '94000', '94000', 1, 'Janvier', 1950, 'membre'),
(16, 'aaa', '$2y$10$.fJluF7Dcer4KKhLzOp7hu5frdawRI3E3tS8EpK0u0Eh/XugNOvaC', 'aa', 'aa', 'aa', NULL, NULL, NULL, NULL, NULL, NULL, 'membre'),
(17, 'felix', '$2y$10$fLw6rine/Vy.jv1JeBKi0.HN1iWR12R7F6YJQEdwA.IfN1YkFh/8S', 'felix@yoohoo.fr', 'lechat', 'felix', 'La litiere', '99900', 'La rue de Garfield', 6, 'Janvier', 2014, 'membre'),
(18, 'aaz', '$2y$10$u.D5QM8YKSeX0aHnQu/N4.OWY3D.jfBF323fm3eynjrTCfx3O2Ztm', 'zzzz', 'aaz', 'aaaa', NULL, NULL, NULL, NULL, NULL, NULL, 'membre'),
(19, 'zerzer', '$2y$10$r7FtYUho8QdSqVJ62dZm/uJlyzX57CcQF5Y.h2aUDxEh1ocMRB/DO', 'zerzer', 'ezr', 'zerzer', NULL, NULL, NULL, NULL, NULL, NULL, 'membre'),
(20, 'zer', '$2y$10$N/LfDgKKmhbWBLZUPDhNKuDo7RDGbXkMRs2mdmT.MRKf1Y6FmeiF6', 'zer', 'zer', 'zer', NULL, NULL, NULL, NULL, NULL, NULL, 'membre');

-- --------------------------------------------------------

--
-- Structure de la table `orderdetails`
--

CREATE TABLE `orderdetails` (
  `id_orderdetails` int(11) NOT NULL,
  `id_products` int(11) NOT NULL,
  `quantityordered` int(11) NOT NULL,
  `priceHT` int(11) NOT NULL,
  `priceTVA` int(11) NOT NULL,
  `priceTTC` int(11) NOT NULL,
  `ordernumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `orderdetails`
--

INSERT INTO `orderdetails` (`id_orderdetails`, `id_products`, `quantityordered`, `priceHT`, `priceTVA`, `priceTTC`, `ordernumber`) VALUES
(21, 12, 1, 1, 0, 1, 19),
(22, 12, 1, 1, 0, 1, 19),
(23, 14, 1, 55156, 11031, 66187, 19),
(24, 15, 1, 784, 157, 941, 19),
(25, 17, 1, 1, 0, 1, 19),
(26, 6, 1, 5, 1, 6, 19),
(27, 6, 1, 5, 1, 6, 19),
(28, 12, 1, 1, 0, 1, 20),
(29, 12, 1, 1, 0, 1, 20),
(30, 14, 1, 55156, 11031, 66187, 20),
(31, 15, 1, 784, 157, 941, 20),
(32, 17, 1, 1, 0, 1, 20),
(33, 6, 1, 5, 1, 6, 20),
(34, 6, 1, 5, 1, 6, 20),
(35, 12, 1, 1, 0, 1, 21),
(36, 12, 1, 1, 0, 1, 21),
(37, 14, 1, 55156, 11031, 66187, 21),
(38, 15, 1, 784, 157, 941, 21),
(39, 17, 1, 1, 0, 1, 21),
(40, 6, 1, 5, 1, 6, 21),
(41, 6, 1, 5, 1, 6, 21),
(42, 12, 1, 1, 0, 1, 22),
(43, 12, 1, 1, 0, 1, 22),
(44, 14, 1, 55156, 11031, 66187, 22),
(45, 15, 1, 784, 157, 941, 22),
(46, 17, 1, 1, 0, 1, 22),
(47, 6, 1, 5, 1, 6, 22),
(48, 6, 1, 5, 1, 6, 22),
(49, 6, 2, 5, 2, 12, 23),
(50, 5, 2, 5, 2, 12, 23),
(51, 7, 4, 5, 4, 24, 23),
(52, 18, 2, 1, 0, 2, 23),
(53, 6, 2, 5, 2, 12, 24),
(54, 5, 2, 5, 2, 12, 24),
(55, 7, 4, 5, 4, 24, 24),
(56, 18, 2, 1, 0, 2, 24),
(57, 6, 3, 5, 3, 18, 24),
(58, 6, 2, 5, 2, 12, 25),
(59, 5, 2, 5, 2, 12, 25),
(60, 7, 4, 5, 4, 24, 25),
(61, 18, 2, 1, 0, 2, 25),
(62, 6, 3, 5, 3, 18, 25),
(63, 6, 2, 5, 2, 12, 26),
(64, 5, 2, 5, 2, 12, 26),
(65, 7, 4, 5, 4, 24, 26),
(66, 18, 2, 1, 0, 2, 26),
(67, 6, 3, 5, 3, 18, 26),
(68, 6, 2, 5, 2, 12, 27),
(69, 5, 2, 5, 2, 12, 27),
(70, 7, 4, 5, 4, 24, 27),
(71, 18, 2, 1, 0, 2, 27),
(72, 6, 3, 5, 3, 18, 27),
(73, 6, 2, 5, 2, 12, 28),
(74, 5, 2, 5, 2, 12, 28),
(75, 7, 4, 5, 4, 24, 28),
(76, 18, 2, 1, 0, 2, 28),
(77, 6, 3, 5, 3, 18, 28),
(78, 6, 2, 5, 2, 12, 29),
(79, 5, 2, 5, 2, 12, 29),
(80, 7, 4, 5, 4, 24, 29),
(81, 18, 2, 1, 0, 2, 29),
(82, 6, 3, 5, 3, 18, 29),
(83, 12, 1, 1, 0, 1, 30),
(84, 12, 1, 1, 0, 1, 30),
(85, 12, 1, 1, 0, 1, 30),
(86, 12, 1, 1, 0, 1, 30),
(87, 12, 1, 1, 0, 1, 31),
(88, 12, 1, 1, 0, 1, 31),
(89, 12, 1, 1, 0, 1, 31),
(90, 12, 1, 1, 0, 1, 31),
(91, 12, 1, 1, 0, 1, 32),
(92, 12, 1, 1, 0, 1, 32),
(93, 12, 1, 1, 0, 1, 32),
(94, 12, 1, 1, 0, 1, 32),
(95, 12, 1, 1, 0, 1, 33),
(96, 12, 1, 1, 0, 1, 33),
(97, 12, 1, 1, 0, 1, 33),
(98, 12, 1, 1, 0, 1, 33),
(99, 12, 1, 1, 0, 1, 34),
(100, 12, 1, 1, 0, 1, 34),
(101, 12, 1, 1, 0, 1, 34),
(102, 12, 1, 1, 0, 1, 35),
(103, 12, 1, 1, 0, 1, 35),
(104, 12, 1, 1, 0, 1, 36),
(105, 12, 1, 1, 0, 1, 36),
(106, 12, 1, 1, 0, 1, 37),
(107, 12, 1, 1, 0, 1, 37),
(108, 12, 1, 1, 0, 1, 37),
(109, 12, 1, 1, 0, 1, 38),
(110, 12, 1, 1, 0, 1, 38),
(111, 12, 1, 1, 0, 1, 38),
(112, 12, 1, 1, 0, 1, 39),
(113, 12, 1, 1, 0, 1, 39),
(114, 12, 1, 1, 0, 1, 40),
(115, 12, 1, 1, 0, 1, 40),
(116, 12, 1, 1, 0, 1, 40),
(117, 23, 9, 3, 5, 32, 41),
(118, 33, 8, 5, 8, 48, 42),
(119, 34, 10, 1, 2, 12, 42),
(120, 40, 2, 2, 1, 5, 43),
(121, 40, 1, 2, 0, 2, 44),
(122, 40, 1, 2, 0, 2, 44),
(123, 40, 10, 2, 4, 24, 44);

-- --------------------------------------------------------

--
-- Structure de la table `orders`
--

CREATE TABLE `orders` (
  `id_orders` int(11) NOT NULL,
  `orderdate` datetime NOT NULL,
  `Statut` varchar(100) NOT NULL DEFAULT 'Annuler',
  `id_client` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `orders`
--

INSERT INTO `orders` (`id_orders`, `orderdate`, `Statut`, `id_client`) VALUES
(19, '2019-01-13 16:39:15', 'En cours de validation', 11),
(20, '2019-01-13 21:16:22', 'En cours de validation', 11),
(21, '2019-01-13 21:37:06', 'En cours de validation', 11),
(22, '2019-01-13 21:43:10', 'En cours de validation', 11),
(23, '2019-01-13 21:53:45', 'En cours de validation', 14),
(24, '2019-01-13 22:26:58', 'En cours de validation', 14),
(25, '2019-01-13 22:48:26', 'En cours de validation', 14),
(26, '2019-01-13 22:49:27', 'En cours de validation', 14),
(27, '2019-01-13 22:50:13', 'En cours de validation', 14),
(28, '2019-01-13 22:50:57', 'En cours de validation', 14),
(29, '2019-01-13 22:52:18', 'En cours de validation', 14),
(30, '2019-01-13 22:53:12', 'En cours de validation', 15),
(31, '2019-01-13 22:54:38', 'En cours de validation', 15),
(32, '2019-01-13 22:55:03', 'En cours de validation', 15),
(33, '2019-01-13 22:56:23', 'En cours de validation', 15),
(34, '2019-01-13 22:57:07', 'En cours de validation', 15),
(35, '2019-01-13 22:58:20', 'En cours de validation', 15),
(36, '2019-01-13 22:59:37', 'En cours de validation', 15),
(37, '2019-01-13 23:00:11', 'En cours de validation', 15),
(39, '2019-01-13 23:00:38', 'En cours de validation', 15),
(40, '2019-01-13 23:01:42', 'En cours de validation', 15),
(41, '2019-09-01 19:27:18', 'En cours de validation', 11),
(42, '2019-09-01 19:32:55', 'En cours de validation', 17),
(43, '2019-10-24 17:07:29', 'En cours de validation', 15),
(44, '2020-01-03 22:26:41', 'Annuler', 11);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `allproducts`
--
ALTER TABLE `allproducts`
  ADD PRIMARY KEY (`id_product`);

--
-- Index pour la table `astuceday`
--
ALTER TABLE `astuceday`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `categorybread`
--
ALTER TABLE `categorybread`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `categorypastry`
--
ALTER TABLE `categorypastry`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `categorysandwich`
--
ALTER TABLE `categorysandwich`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `categorysoda`
--
ALTER TABLE `categorysoda`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD PRIMARY KEY (`id_orderdetails`);

--
-- Index pour la table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id_orders`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `allproducts`
--
ALTER TABLE `allproducts`
  MODIFY `id_product` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT pour la table `astuceday`
--
ALTER TABLE `astuceday`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `categorybread`
--
ALTER TABLE `categorybread`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT pour la table `categorypastry`
--
ALTER TABLE `categorypastry`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `categorysandwich`
--
ALTER TABLE `categorysandwich`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `categorysoda`
--
ALTER TABLE `categorysoda`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT pour la table `orderdetails`
--
ALTER TABLE `orderdetails`
  MODIFY `id_orderdetails` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;

--
-- AUTO_INCREMENT pour la table `orders`
--
ALTER TABLE `orders`
  MODIFY `id_orders` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
